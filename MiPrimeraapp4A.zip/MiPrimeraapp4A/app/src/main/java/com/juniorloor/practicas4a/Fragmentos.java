package com.juniorloor.practicas4a;

import android.net.Uri;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Fragmentos extends AppCompatActivity implements View.OnClickListener, FrgUno.OnFragmentInteractionListener, FrgDos.OnFragmentInteractionListener{

    Button botonFranUno, botonFranDos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragmentos);

        botonFranUno = (Button) findViewById(R.id.btnFrgUno);
        botonFranDos = (Button)findViewById(R.id.btnFrgDos);

        botonFranUno.setOnClickListener(this);
        botonFranDos.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnFrgUno:
               FrgUno frgmentoUno = new FrgUno();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.contenedor,frgmentoUno);
                transaction.commit();
                break;
        }
        switch (v.getId()){
            case R.id.btnFrgDos:
                FrgDos frgmentoDos = new FrgDos();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.contenedor,frgmentoDos);
                transaction.commit();
                break;
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
